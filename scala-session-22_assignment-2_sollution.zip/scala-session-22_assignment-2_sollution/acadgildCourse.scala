object Courses extends App{
	val courses: Map[String,Int]=
		Map(
			"Android" -> 12999,
			"Big Data Development" -> 17999,
			"Spark" -> 19999
		)
		println(courses)
		println("Enter course name to find price for that: ")
		var price :String = scala.io.StdIn.readLine()
		
		price match{
			case "Android" => println(12999)
			case "Big Data Development" => println(17999)
			case "Spark" => println(19999)
			case _ => println(" Couse doesn't exist, Enter other course")
		}
}

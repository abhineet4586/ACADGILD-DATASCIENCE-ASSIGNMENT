// fib object creation
object fib
{
    // Defining fib function
    def fib( n : Int ) : Int = { 
    var a = 1 
    var b = 2 
    var i = 1 
    println(a)
   
    // Iteration untill 'i' lesser than 'n'
    while( i < n ) { 
      val c = a + b 
      a = b 
      b = c 
      i = i + 1 
      println(a)
   }  
   
   return a 
 }

    // Main function definition taking input from command line 
    def main(args: Array[String]) {
        var nth_element = 0
        println("Fibonacci series of " + args(0) + " elements : ")
        nth_element = fib(args(0).toInt)
    }
 }


// Singelton object creation
object fib
{
    // difining Fibonacci recursive function
    def fib( n : Int) : Int = {
	
	if (n == 1){
        	return n
	}
	if (n == 2){
		return(n)
	}
	
	return fib(n-1) + fib(n-2)
        }
    // Defining Main function...
    def main(args: Array[String]) {
	var i = 1
	println("Fibonacci series of " + args(0) + " elements (starting from 1): ")
	// Iteration while i less than or equal to number of element passed through command line....
	while(i <= (args(0).toInt)){
		println(fib(i))
		i = i+1
	}
    }
 }

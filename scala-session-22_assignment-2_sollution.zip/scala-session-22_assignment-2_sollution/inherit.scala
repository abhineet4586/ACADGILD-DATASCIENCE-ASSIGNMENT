// Employee class Definition
class Employee{  
    var salary:Float = 10000  
}  
// Programmer class definition which inherits employee class  
class Programmer extends Employee{  
    var bonus:Int = 5000  
    println("Salary = "+salary)  
    println("Bonus = "+bonus)  
}  

// Main Object creation  
object MainObject{  
    // Defining Main Function
    def main(args:Array[String]){  
        new Programmer()  
    }  
} 

class addSquare {
	// 'x' and 'y' are the inputs of partial function (addSquare) and '7' is constant
	val add = (x:Int,y:Int)=>7+x+y

	// Square is another function that takes 'add' as input
	def square(add:Int) : Int = add*add
}

object addSquare extends App{
	val a = new addSquare()
	var b = a.add(9,11)
	println("Sum of three number = " +b)
	println("Square of result of partial function = " +a.square(b))
}
